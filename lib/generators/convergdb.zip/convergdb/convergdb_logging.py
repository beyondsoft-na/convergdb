# simple logging... makes our entries easier to find in cloudwatch logs
def convergdb_log(entry):
  print("[CONVERGDB] " + entry)
