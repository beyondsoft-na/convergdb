from convergdb_logging import *

import time

# !SPARK PARTITION HANDLING

# creates a list of tuples representing the list slice ranges
# for each chunk.
def split_indices(count, grouping):
  # creating a set of tuples
  ret = []
  if (grouping == 1) and (count == 1):
    ret.append((0, 1))
    return ret
  elif grouping >= count:
    # full range provided as one group (tuple)
    ret.append((0, count))
    return ret
  else:
    # number of groups to create
    grouping_range = 0
    if count % grouping == 0:
      # grouping is a factor of count
      grouping_range = int(count / grouping)
    else:
      # add a group for the remainder
      grouping_range = int(count / grouping) + 1
    # will execute at least once
    for i in range(grouping_range):
      lo = i * grouping
      hi = min(lo + grouping, count)
      ret.append((lo, hi))
  return ret

# calculates the total size in bytes for the list of files in diff...
# as looked up by the value stored in available dict
def loadable_file_size(available, diff):
  convergdb_log("calculating total size of " + str(len(diff)) + " files...")
  st = time.time()
  size = 0
  for d in diff:
    size += available[d]
  et = time.time()
  convergdb_log("total size calculation took " + str(et - st) + " seconds")
  convergdb_log("source data total " + str(size) + " bytes")
  return size

def coalesce_partition_target(dpu, estimated_source_bytes):
  max_partitions_per_dpu = 8
  target_compression_factor = 3

  target_file_size = 256*(1024**2)
  max_partitions = dpu * max_partitions_per_dpu

  partition_count = round(float(estimated_source_bytes) / float(target_compression_factor) / float(target_file_size))
  partition_count = min([max([partition_count, 1]), max_partitions])
  return partition_count

def calculate_spark_partitions(structure, total_bytes, dpu):
  convergdb_log("dpu from current run_id: " + str(dpu))
  partitions = coalesce_partition_target(
    dpu,
    total_bytes
  )
  convergdb_log("calculated partition count: " + str(partitions))
  return int(partitions)

def available_memory_in_this_cluster(dpu):
  bytes_per_dpu = 16 * (1024**3) # 16GB
  usable_portion = 0.25
  return int(dpu * bytes_per_dpu * usable_portion)

def calculate_chunk_count(batch_uncompressed_bytes, batch_file_count, dpu):
  return batch_file_count / int(
    max(
      1,
      batch_uncompressed_bytes / available_memory_in_this_cluster(dpu)
    )
  )
